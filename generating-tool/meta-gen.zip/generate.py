import sys
import generator_cls
generator_obj = generator_cls.generator()
generator_obj.generate(sys.argv)
